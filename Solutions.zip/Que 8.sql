-- Que 8: Join relevant tables to find the category-wise distribution of pizzas.

SELECT category, count(name) AS pizza_name
FROM pizza_types
GROUP BY category
ORDER BY pizza_name DESC;
