-- Que 1: the total number of orders placed

SELECT count(order_id) as total_order FROM orders;
